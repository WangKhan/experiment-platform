/**
 * 默认配置
 */

module.exports = {
  jwtSecret: '3301a30b-7355-4398-bc02-331eb32c9f64'
}